import numpy as np
import sys
sys.path.append('..')
import rgbcolor
dc = rgbcolor.DColor()
import example
example.example(dc)
