import numpy as np
import sys
sys.path.append('..')
import hsvcolor
dc = hsvcolor.DColor()
import example
example.example(dc)
