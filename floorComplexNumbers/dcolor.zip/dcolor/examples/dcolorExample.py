import numpy as np
import sys
sys.path.append('..')
import dcolor
dc = dcolor.DColor()
import example
example.example(dc)

